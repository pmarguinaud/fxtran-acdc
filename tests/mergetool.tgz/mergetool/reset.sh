#!/bin/bash

git merge --abort
rm -f *.expand.F90 *.xml *.orig


