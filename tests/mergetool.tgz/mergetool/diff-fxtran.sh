#!/bin/bash

git config difftool.fxtran-difftool.cmd 'fxtran-difftool $LOCAL $REMOTE'

git difftool -t fxtran-difftool branch1 branch2 -- cpg_gp_hyd.F90
