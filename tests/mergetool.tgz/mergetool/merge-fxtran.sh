#!/bin/bash

git config mergetool.fxtran-mergetool.cmd 'fxtran-mergetool $BASE $LOCAL $REMOTE $MERGED'
git config mergetool.fxtran-mergetool.trustexitcode true

git merge --abort
rm -f *.expand.F90 *.xml *.orig
git merge branch1

git mergetool -t fxtran-mergetool

