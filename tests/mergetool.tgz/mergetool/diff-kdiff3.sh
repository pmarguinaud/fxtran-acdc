#!/bin/bash

git difftool branch1 branch2 -- cpg_gp_hyd.F90

